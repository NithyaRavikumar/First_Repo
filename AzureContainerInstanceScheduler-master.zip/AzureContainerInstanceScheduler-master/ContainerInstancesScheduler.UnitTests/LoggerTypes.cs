﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContainerInstancesScheduler.UnitTests
{
    public enum LoggerTypes
    {
        Null,
        List
    }
}
